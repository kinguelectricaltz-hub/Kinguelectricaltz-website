<?php get_header(); ?>
<main>
  <h1>Welcome to Kingu Electrical Company Limited</h1>
  <p>Quality Electrical Services with a Professional Experience</p>
</main>
<?php get_footer(); ?>