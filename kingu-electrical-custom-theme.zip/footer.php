<footer>
  <p>&copy; <?php echo date('Y'); ?> Kingu Electrical Company Limited</p>
</footer>
<?php wp_footer(); ?>
</body></html>