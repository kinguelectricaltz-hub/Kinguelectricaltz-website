Kingu Electrical Elementor Kit

Steps:
1. Install WordPress
2. Install Elementor Plugin
3. Create pages: Home, About, Services, Projects, Contact
4. Copy content from provided HTML into Elementor sections
5. Apply colors:
   - Green: #1f6f43
   - Red: #c62828
6. Add contact form using Elementor Forms + SMTP plugin
